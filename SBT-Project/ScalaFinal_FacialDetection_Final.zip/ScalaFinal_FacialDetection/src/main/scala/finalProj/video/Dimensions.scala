package finalProj.video

/**
 * Created by Lloyd on 2/14/16.
 */

/**
 * Tuple-like class for holding width and height in pixels
 */
case class Dimensions(width: Int, height: Int)
