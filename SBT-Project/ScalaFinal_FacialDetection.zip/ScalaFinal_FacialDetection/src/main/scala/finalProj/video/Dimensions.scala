package finalProj.video



/**
 * Tuple-like class for holding width and height in pixels
 */
case class Dimensions(width: Int, height: Int)
